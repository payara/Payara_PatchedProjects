/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 * 
 * Copyright (c) 1997-2010 Oracle and/or its affiliates. All rights reserved.
 * 
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 * 
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * 
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 * 
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 * 
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package corba.poapolicies;

import Util.FactoryHelper;
import org.omg.PortableServer.POA;

class Waiter extends Thread {
    BasicObjectFactoryImpl f;
    POA p;
    public Waiter(POA p, BasicObjectFactoryImpl f) {
        this.f = f;
        this.p = p;
    }
    public void run() {
        try {
            synchronized (f.doneCV) {
                f.doneCV.wait();
                p.destroy(true, true);
            }
        } catch (InterruptedException ex) { }
    }
}

public class HelloServer 
{
    public static boolean debug = false;

    public static void main(String[] args) {
        try {
            String debugp = System.getProperty("DebugPOA");
            if (debugp != null)
                debug = true;

            POAFactory f = null;
            String factory = System.getProperty("POAFactory");
            System.out.println("Server will use factory:" + factory);

            System.out.println("Class path: " + System.getProperty("java.class.path"));


            if (factory != null && !factory.equals(""))
                f = (POAFactory) Class.forName(factory).newInstance();

            Utility u = new Utility(args);

            POA poa = (POA) u.getORB().resolve_initial_references("RootPOA");
            
            if (poa == null)
                System.out.println("POA is null :(");

            POA thePOA = f == null ? poa : f.createPOA(poa);

            BasicObjectFactoryImpl theFactory;
            if (f == null)
                theFactory = new BasicObjectFactoryImpl();
            else
                theFactory = (BasicObjectFactoryImpl)
                    Class.forName(f.getObjectFactoryName()).newInstance();

            System.out.println("Got the basic object factory");


            theFactory.setPOA(thePOA);
            
            byte[] id = thePOA.activate_object(theFactory);
            
            u.writeFactory(FactoryHelper.narrow(thePOA.servant_to_reference(theFactory)));          
            
            thePOA.the_POAManager().activate();

            // What does this thing do???????
            new Waiter(poa, theFactory).start();

            System.out.println("Server is ready.");
            u.getORB().run();
            
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
