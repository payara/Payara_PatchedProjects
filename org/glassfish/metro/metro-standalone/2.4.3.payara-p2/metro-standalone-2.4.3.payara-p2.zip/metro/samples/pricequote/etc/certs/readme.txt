Files local_policy.jar and US_export_policy.jar should be included here. These files are included in Java Cryptography Extension.
Java Cryptography Extension can be downloaded for example at following location:
http://www.oracle.com/technetwork/java/javase/downloads/jce8-download-2133166.html