package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class TableRowGroupBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.TableRowGroup.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), TableRowGroupBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_row_group");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "tableRowGroup");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "tableRowGroup");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT,
                com.sun.webui.jsf.design.CategoryDescriptors.DATA,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "TableRowGroup_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "TableRowGroup_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "TableRowGroup_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "TableRowGroup_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("onClick", this.beanClass, "getOnClick", "setOnClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("footerText", this.beanClass, "getFooterText", "setFooterText");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_footerText_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_footerText_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("footerText",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyPress", this.beanClass, "getOnKeyPress", "setOnKeyPress");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onKeyPress_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onKeyPress_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyPress",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("selectMultipleToggleButton", this.beanClass, "isSelectMultipleToggleButton", "setSelectMultipleToggleButton");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_selectMultipleToggleButton_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_selectMultipleToggleButton_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("selectMultipleToggleButton",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("char", this.beanClass, "getChar", "setChar");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_char_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_char_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("charOff", this.beanClass, "getCharOff", "setCharOff");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_charOff_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_charOff_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("tableDataSorter", this.beanClass, "getTableDataSorter", "setTableDataSorter");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_tableDataSorter_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_tableDataSorter_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("tableDataSorter",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.FieldKeyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("bgColor", this.beanClass, "getBgColor", "setBgColor");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_bgColor_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_bgColor_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("styleClasses", this.beanClass, "getStyleClasses", "setStyleClasses");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_styleClasses_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_styleClasses_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClasses",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StyleClassPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("selected", this.beanClass, "isSelected", "setSelected");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_selected_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_selected_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("selected",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("groupToggleButton", this.beanClass, "isGroupToggleButton", "setGroupToggleButton");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_groupToggleButton_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_groupToggleButton_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("groupToggleButton",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseUp", this.beanClass, "getOnMouseUp", "setOnMouseUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onMouseUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onMouseUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("multipleColumnFooters", this.beanClass, "isMultipleColumnFooters", "setMultipleColumnFooters");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_multipleColumnFooters_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_multipleColumnFooters_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("multipleColumnFooters",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyDown", this.beanClass, "getOnKeyDown", "setOnKeyDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onKeyDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onKeyDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraFooterHtml", this.beanClass, "getExtraFooterHtml", "setExtraFooterHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_extraFooterHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_extraFooterHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraFooterHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOver", this.beanClass, "getOnMouseOver", "setOnMouseOver");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onMouseOver_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onMouseOver_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOver",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("aboveColumnFooter", this.beanClass, "isAboveColumnFooter", "setAboveColumnFooter");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_aboveColumnFooter_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_aboveColumnFooter_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("aboveColumnFooter",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("sourceData", this.beanClass, "getSourceData", "setSourceData");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_sourceData_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_sourceData_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("sourceData",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("tableDataFilter", this.beanClass, "getTableDataFilter", "setTableDataFilter");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_tableDataFilter_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_tableDataFilter_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("tableDataFilter",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.FieldKeyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("aboveColumnHeader", this.beanClass, "isAboveColumnHeader", "setAboveColumnHeader");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_aboveColumnHeader_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_aboveColumnHeader_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("aboveColumnHeader",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("toolTip", this.beanClass, "getToolTip", "setToolTip");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_toolTip_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_toolTip_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("toolTip",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyUp", this.beanClass, "getOnKeyUp", "setOnKeyUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onKeyUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onKeyUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("align", this.beanClass, "getAlign", "setAlign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_align_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_align_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("align",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.TableAlignEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onDblClick", this.beanClass, "getOnDblClick", "setOnDblClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onDblClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onDblClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onDblClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseMove", this.beanClass, "getOnMouseMove", "setOnMouseMove");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onMouseMove_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onMouseMove_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseMove",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rows", this.beanClass, "getRows", "setRows");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_rows_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_rows_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rows",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("collapsed", this.beanClass, "isCollapsed", "setCollapsed");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_collapsed_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_collapsed_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("collapsed",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseDown", this.beanClass, "getOnMouseDown", "setOnMouseDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onMouseDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onMouseDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("multipleTableColumnFooters", this.beanClass, "isMultipleTableColumnFooters", "setMultipleTableColumnFooters");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_multipleTableColumnFooters_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_multipleTableColumnFooters_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("multipleTableColumnFooters",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraHeaderHtml", this.beanClass, "getExtraHeaderHtml", "setExtraHeaderHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_extraHeaderHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_extraHeaderHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraHeaderHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("valign", this.beanClass, "getValign", "setValign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_valign_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_valign_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("valign",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.HtmlVerticalAlignEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("sourceVar", this.beanClass, "getSourceVar", "setSourceVar");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_sourceVar_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_sourceVar_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("sourceVar",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("first", this.beanClass, "getFirst", "setFirst");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_first_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_first_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("first",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("headerText", this.beanClass, "getHeaderText", "setHeaderText");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_headerText_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_headerText_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("headerText",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("emptyDataMsg", this.beanClass, "getEmptyDataMsg", "setEmptyDataMsg");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_emptyDataMsg_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_emptyDataMsg_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("emptyDataMsg",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOut", this.beanClass, "getOnMouseOut", "setOnMouseOut");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableRowGroup_onMouseOut_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableRowGroup_onMouseOut_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOut",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
