package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class PanelLayoutBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.PanelLayout.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), PanelLayoutBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_layout_panel");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "layoutPanel");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"projrave_ui_elements_palette_wdstk-jsf1.2_propsheets_panel_layout_props");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "panelLayout");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "PanelLayout_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "PanelLayout_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "PanelLayout_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "PanelLayout_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("panelLayout", this.beanClass, "getPanelLayout", "setPanelLayout");
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_panelLayout_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_panelLayout_shortDescription"));
                attributeDescriptor = new AttributeDescriptor("panelLayout",false,null,false);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("style", this.beanClass, "getStyle", "setStyle");
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_style_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_style_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("style",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.jsfcl.std.css.CssStylePropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("styleClass", this.beanClass, "getStyleClass", "setStyleClass");
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_styleClass_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_styleClass_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClass",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StyleClassPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("PanelLayout_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("PanelLayout_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
