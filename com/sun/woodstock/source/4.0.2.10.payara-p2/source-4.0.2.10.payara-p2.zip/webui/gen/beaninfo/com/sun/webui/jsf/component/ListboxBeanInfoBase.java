package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class ListboxBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.Listbox.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), ListboxBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("Listbox_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("Listbox_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_listbox");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "listbox");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"projrave_ui_elements_palette_wdstk-jsf1.2_propsheets_listbox_props");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "listbox");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
            String defaultPropertyName = "value";
            PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors();
            if (propertyDescriptors != null) {
                for (int i = 0; i < propertyDescriptors.length; i++) {
                    if (defaultPropertyName.equals(propertyDescriptors[i].getName())) {
                        defaultPropertyIndex = i;
                        break;
                    }
                }
            }
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
            String defaultEventName = "valueChange";
            EventSetDescriptor[] eventDescriptors = getEventSetDescriptors();
            if (eventDescriptors != null) {
                for (int i = 0; i < eventDescriptors.length; i++) {
                    if (defaultEventName.equals(eventDescriptors[i].getName())) {
                        defaultEventIndex = i;
                        break;
                    }
                }
            } 
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.DATA,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.ACCESSIBILITY,
                com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "Listbox_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "Listbox_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "Listbox_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "Listbox_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("onSelect", this.beanClass, "getOnSelect", "setOnSelect");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Listbox_onSelect_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Listbox_onSelect_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("toolTip", this.beanClass, "getToolTip", "setToolTip");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Listbox_toolTip_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Listbox_toolTip_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("toolTip",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("value", this.beanClass, "getValue", "setValue");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Listbox_value_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Listbox_value_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("monospace", this.beanClass, "isMonospace", "setMonospace");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Listbox_monospace_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Listbox_monospace_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("monospace",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("multiple", this.beanClass, "isMultiple", "setMultiple");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Listbox_multiple_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Listbox_multiple_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("multiple",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onClick", this.beanClass, "getOnClick", "setOnClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onKeyPress", this.beanClass, "getOnKeyPress", "setOnKeyPress");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onKeyPress_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onKeyPress_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyPress",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.ListSelector
                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("ListSelector_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("ListSelector_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("validator", this.beanClass, "getValidator", "setValidator");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_validator_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_validator_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.ValidatorPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("tabIndex", this.beanClass, "getTabIndex", "setTabIndex");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_tabIndex_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_tabIndex_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("tabIndex",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ACCESSIBILITY);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("validatorExpression", this.beanClass, "getValidatorExpression", "setValidatorExpression");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_validatorExpression_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_validatorExpression_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("validatorExpression",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.ValidatorPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("valueChangeListener", this.beanClass, "getValueChangeListener", "setValueChangeListener");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_valueChangeListener_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_valueChangeListener_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("selected", this.beanClass, "getSelected", "setSelected");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_selected_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_selected_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("selected",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onMouseUp", this.beanClass, "getOnMouseUp", "setOnMouseUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onMouseUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onMouseUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("style", this.beanClass, "getStyle", "setStyle");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_style_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_style_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("style",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.jsfcl.std.css.CssStylePropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("converter", this.beanClass, "getConverter", "setConverter");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_converter_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_converter_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("converter",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIInput
                propertyDescriptor =
                    new PropertyDescriptor("localValue", this.beanClass, "getLocalValue", null);
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIInput_localValue_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIInput_localValue_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.ListSelector
                propertyDescriptor =
                    new PropertyDescriptor("labelOnTop", this.beanClass, "isLabelOnTop", "setLabelOnTop");
                propertyDescriptor.setDisplayName(resourceBundle.getString("ListSelector_labelOnTop_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("ListSelector_labelOnTop_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("labelOnTop",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onFocus", this.beanClass, "getOnFocus", "setOnFocus");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onFocus_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onFocus_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onFocus",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("required", this.beanClass, "isRequired", "setRequired");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_required_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_required_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("required",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onKeyDown", this.beanClass, "getOnKeyDown", "setOnKeyDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onKeyDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onKeyDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onBlur", this.beanClass, "getOnBlur", "setOnBlur");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onBlur_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onBlur_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onBlur",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onMouseOver", this.beanClass, "getOnMouseOver", "setOnMouseOver");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onMouseOver_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onMouseOver_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOver",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onKeyUp", this.beanClass, "getOnKeyUp", "setOnKeyUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onKeyUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onKeyUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("styleClass", this.beanClass, "getStyleClass", "setStyleClass");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_styleClass_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_styleClass_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClass",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StyleClassPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("label", this.beanClass, "getLabel", "setLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_label_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_label_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("label",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.ListSelector
                propertyDescriptor =
                    new PropertyDescriptor("separators", this.beanClass, "isSeparators", "setSeparators");
                propertyDescriptor.setDisplayName(resourceBundle.getString("ListSelector_separators_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("ListSelector_separators_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("separators",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onMouseMove", this.beanClass, "getOnMouseMove", "setOnMouseMove");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onMouseMove_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onMouseMove_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseMove",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onDblClick", this.beanClass, "getOnDblClick", "setOnDblClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onDblClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onDblClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onDblClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.ListSelector
                propertyDescriptor =
                    new PropertyDescriptor("rows", this.beanClass, "getRows", "setRows");
                propertyDescriptor.setDisplayName(resourceBundle.getString("ListSelector_rows_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("ListSelector_rows_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rows",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("valueChangeListenerExpression", this.beanClass, "getValueChangeListenerExpression", "setValueChangeListenerExpression");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_valueChangeListenerExpression_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_valueChangeListenerExpression_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("valueChangeListenerExpression",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.MethodBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("immediate", this.beanClass, "isImmediate", "setImmediate");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_immediate_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_immediate_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("immediate",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("readOnly", this.beanClass, "isReadOnly", "setReadOnly");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_readOnly_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_readOnly_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("readOnly",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("items", this.beanClass, "getItems", "setItems");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_items_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_items_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("items",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIInput
                propertyDescriptor =
                    new PropertyDescriptor("submittedValue", this.beanClass, "getSubmittedValue", "setSubmittedValue");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIInput_submittedValue_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIInput_submittedValue_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onChange", this.beanClass, "getOnChange", "setOnChange");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onChange_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onChange_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onChange",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onMouseDown", this.beanClass, "getOnMouseDown", "setOnMouseDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onMouseDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onMouseDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("labelLevel", this.beanClass, "getLabelLevel", "setLabelLevel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_labelLevel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_labelLevel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("labelLevel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.LabelLevelsEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("disabled", this.beanClass, "isDisabled", "setDisabled");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_disabled_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_disabled_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("disabled",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.Selector
                propertyDescriptor =
                    new PropertyDescriptor("onMouseOut", this.beanClass, "getOnMouseOut", "setOnMouseOut");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Selector_onMouseOut_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Selector_onMouseOut_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOut",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        if (eventSetDescriptors == null) {
            try {
                Map<String,EventSetDescriptor> eventSetDescriptorMap = new HashMap<String,EventSetDescriptor>();
                EventSetDescriptor eventSetDescriptor;
                PropertyDescriptor eventPropertyDescriptor;
                

                // Event set declaration inherited from javax.faces.component.UIInput
                eventSetDescriptor = new EventSetDescriptor("valueChange",
                    javax.faces.event.ValueChangeListener.class,
                    new Method[] {
                        javax.faces.event.ValueChangeListener.class.getMethod(
                            "processValueChange", 
                            new Class[] {javax.faces.event.ValueChangeEvent.class, })
                    },
                    Listbox.class.getMethod("addValueChangeListener", new Class[] {javax.faces.event.ValueChangeListener.class}),
                    Listbox.class.getMethod("removeValueChangeListener", new Class[] {javax.faces.event.ValueChangeListener.class}));
                eventPropertyDescriptor = null;
                for (PropertyDescriptor propertyDescriptor : this.getPropertyDescriptors()) {
                    if (propertyDescriptor.getName().equals("valueChangeListenerExpression")) {
                        eventPropertyDescriptor = propertyDescriptor;
                        break;
                    }
                }
                eventSetDescriptor.setValue(Constants.EventSetDescriptor.BINDING_PROPERTY, eventPropertyDescriptor);
                eventSetDescriptorMap.put(eventSetDescriptor.getName(), eventSetDescriptor);

                // Event set declaration inherited from javax.faces.component.UIInput
                eventSetDescriptor = new EventSetDescriptor("validate",
                    javax.faces.validator.Validator.class,
                    new Method[] {
                        javax.faces.validator.Validator.class.getMethod(
                            "validate", 
                            new Class[] {javax.faces.context.FacesContext.class, javax.faces.component.UIComponent.class, java.lang.Object.class, })
                    },
                    null,
                    null);
                eventPropertyDescriptor = null;
                for (PropertyDescriptor propertyDescriptor : this.getPropertyDescriptors()) {
                    if (propertyDescriptor.getName().equals("validatorExpression")) {
                        eventPropertyDescriptor = propertyDescriptor;
                        break;
                    }
                }
                eventSetDescriptor.setValue(Constants.EventSetDescriptor.BINDING_PROPERTY, eventPropertyDescriptor);
                eventSetDescriptorMap.put(eventSetDescriptor.getName(), eventSetDescriptor);

                Collection<EventSetDescriptor> eventSetDescriptorCollection = 
                    eventSetDescriptorMap.values();
                eventSetDescriptors =
                    eventSetDescriptorCollection.toArray(new EventSetDescriptor[eventSetDescriptorCollection.size()]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
