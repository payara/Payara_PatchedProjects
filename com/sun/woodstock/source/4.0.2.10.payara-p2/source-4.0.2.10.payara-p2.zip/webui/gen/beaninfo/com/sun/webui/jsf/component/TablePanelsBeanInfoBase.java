package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class TablePanelsBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.TablePanels.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), TablePanelsBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("TablePanels_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("TablePanels_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "tablePanels");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "TablePanels_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "TablePanels_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "TablePanels_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "TablePanels_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("headers", this.beanClass, "getHeaders", "setHeaders");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_headers_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_headers_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("headers",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onClick", this.beanClass, "getOnClick", "setOnClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("scope", this.beanClass, "getScope", "setScope");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_scope_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_scope_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("scope",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyPress", this.beanClass, "getOnKeyPress", "setOnKeyPress");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onKeyPress_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onKeyPress_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyPress",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("char", this.beanClass, "getChar", "setChar");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_char_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_char_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("char",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("charOff", this.beanClass, "getCharOff", "setCharOff");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_charOff_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_charOff_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("charOff",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("noWrap", this.beanClass, "isNoWrap", "setNoWrap");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_noWrap_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_noWrap_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("noWrap",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("bgColor", this.beanClass, "getBgColor", "setBgColor");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_bgColor_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_bgColor_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("bgColor",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("height", this.beanClass, "getHeight", "setHeight");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_height_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_height_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("height",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseUp", this.beanClass, "getOnMouseUp", "setOnMouseUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onMouseUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onMouseUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("style", this.beanClass, "getStyle", "setStyle");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_style_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_style_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("style",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("preferencesPanel", this.beanClass, "isPreferencesPanel", "setPreferencesPanel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_preferencesPanel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_preferencesPanel_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("colSpan", this.beanClass, "getColSpan", "setColSpan");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_colSpan_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_colSpan_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("colSpan",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rowSpan", this.beanClass, "getRowSpan", "setRowSpan");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_rowSpan_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_rowSpan_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rowSpan",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyDown", this.beanClass, "getOnKeyDown", "setOnKeyDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onKeyDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onKeyDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("axis", this.beanClass, "getAxis", "setAxis");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_axis_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_axis_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("axis",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOver", this.beanClass, "getOnMouseOver", "setOnMouseOver");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onMouseOver_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onMouseOver_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOver",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("toolTip", this.beanClass, "getToolTip", "setToolTip");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_toolTip_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_toolTip_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("toolTip",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyUp", this.beanClass, "getOnKeyUp", "setOnKeyUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onKeyUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onKeyUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("width", this.beanClass, "getWidth", "setWidth");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_width_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_width_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("width",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("styleClass", this.beanClass, "getStyleClass", "setStyleClass");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_styleClass_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_styleClass_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClass",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("align", this.beanClass, "getAlign", "setAlign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_align_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_align_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("align",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("abbr", this.beanClass, "getAbbr", "setAbbr");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_abbr_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_abbr_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("abbr",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("filterPanel", this.beanClass, "isFilterPanel", "setFilterPanel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_filterPanel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_filterPanel_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraHtml", this.beanClass, "getExtraHtml", "setExtraHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_extraHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_extraHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onDblClick", this.beanClass, "getOnDblClick", "setOnDblClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onDblClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onDblClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onDblClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseMove", this.beanClass, "getOnMouseMove", "setOnMouseMove");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onMouseMove_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onMouseMove_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseMove",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseDown", this.beanClass, "getOnMouseDown", "setOnMouseDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onMouseDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onMouseDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("valign", this.beanClass, "getValign", "setValign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_valign_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_valign_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("valign",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOut", this.beanClass, "getOnMouseOut", "setOnMouseOut");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TablePanels_onMouseOut_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TablePanels_onMouseOut_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOut",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIComponentBase
                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIComponentBase_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIComponentBase_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIComponentBase
                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIComponentBase_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIComponentBase_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
