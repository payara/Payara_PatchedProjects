package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class SchedulerBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.Scheduler.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), SchedulerBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("Scheduler_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("Scheduler_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_scheduler");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "scheduler");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"projrave_ui_elements_palette_wdstk-jsf1.2_propsheets_scheduler_props");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "scheduler");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
            String defaultPropertyName = "value";
            PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors();
            if (propertyDescriptors != null) {
                for (int i = 0; i < propertyDescriptors.length; i++) {
                    if (defaultPropertyName.equals(propertyDescriptors[i].getName())) {
                        defaultPropertyIndex = i;
                        break;
                    }
                }
            }
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
            String defaultEventName = "valueChange";
            EventSetDescriptor[] eventDescriptors = getEventSetDescriptors();
            if (eventDescriptors != null) {
                for (int i = 0; i < eventDescriptors.length; i++) {
                    if (defaultEventName.equals(eventDescriptors[i].getName())) {
                        defaultEventIndex = i;
                        break;
                    }
                }
            } 
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.DATA,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.ACCESSIBILITY,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "Scheduler_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "Scheduler_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "Scheduler_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "Scheduler_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("endTimeLabel", this.beanClass, "getEndTimeLabel", "setEndTimeLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_endTimeLabel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_endTimeLabel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("endTimeLabel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("tabIndex", this.beanClass, "getTabIndex", "setTabIndex");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_tabIndex_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_tabIndex_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("tabIndex",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ACCESSIBILITY);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("styleClass", this.beanClass, "getStyleClass", "setStyleClass");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_styleClass_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_styleClass_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClass",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StyleClassPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("timeZone", this.beanClass, "getTimeZone", "setTimeZone");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_timeZone_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_timeZone_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("timeZone",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("previewButton", this.beanClass, "isPreviewButton", "setPreviewButton");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_previewButton_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_previewButton_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("previewButton",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("startTimeLabel", this.beanClass, "getStartTimeLabel", "setStartTimeLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_startTimeLabel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_startTimeLabel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("startTimeLabel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("endTime", this.beanClass, "isEndTime", "setEndTime");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_endTime_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_endTime_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("endTime",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("repeatIntervalItems", this.beanClass, "getRepeatIntervalItems", "setRepeatIntervalItems");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_repeatIntervalItems_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_repeatIntervalItems_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("repeatIntervalItems",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.RepeatIntervalEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("requiredLegend", this.beanClass, "isRequiredLegend", "setRequiredLegend");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_requiredLegend_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_requiredLegend_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("requiredLegend",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("repeating", this.beanClass, "isRepeating", "setRepeating");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_repeating_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_repeating_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("repeating",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("startTime", this.beanClass, "isStartTime", "setStartTime");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_startTime_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_startTime_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("startTime",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("repeatLimitLabel", this.beanClass, "getRepeatLimitLabel", "setRepeatLimitLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_repeatLimitLabel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_repeatLimitLabel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("repeatLimitLabel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("repeatIntervalLabel", this.beanClass, "getRepeatIntervalLabel", "setRepeatIntervalLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_repeatIntervalLabel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_repeatIntervalLabel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("repeatIntervalLabel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("dateFormatPatternHelp", this.beanClass, "getDateFormatPatternHelp", "setDateFormatPatternHelp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_dateFormatPatternHelp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_dateFormatPatternHelp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("dateFormatPatternHelp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("readOnly", this.beanClass, "isReadOnly", "setReadOnly");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_readOnly_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_readOnly_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("readOnly",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("style", this.beanClass, "getStyle", "setStyle");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_style_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_style_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("style",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.jsfcl.std.css.CssStylePropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("repeatUnitItems", this.beanClass, "getRepeatUnitItems", "setRepeatUnitItems");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_repeatUnitItems_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_repeatUnitItems_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("repeatUnitItems",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.RepeatUnitEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("maxDate", this.beanClass, "getMaxDate", "setMaxDate");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_maxDate_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_maxDate_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("maxDate",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("converter", this.beanClass, "getConverter", "setConverter");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_converter_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_converter_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("dateLabel", this.beanClass, "getDateLabel", "setDateLabel");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_dateLabel_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_dateLabel_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("dateLabel",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("value", this.beanClass, "getValue", "setValue");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_value_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_value_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("value",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("minDate", this.beanClass, "getMinDate", "setMinDate");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_minDate_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_minDate_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("minDate",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.binding.ValueBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("dateFormatPattern", this.beanClass, "getDateFormatPattern", "setDateFormatPattern");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_dateFormatPattern_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_dateFormatPattern_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("dateFormatPattern",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.DateFormatPatternsEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("required", this.beanClass, "isRequired", "setRequired");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_required_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_required_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("limitRepeating", this.beanClass, "isLimitRepeating", "setLimitRepeating");
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_limitRepeating_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_limitRepeating_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("limitRepeating",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("disabled", this.beanClass, "isDisabled", "setDisabled");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("Scheduler_disabled_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("Scheduler_disabled_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("valueChangeListenerExpression", this.beanClass, "getValueChangeListenerExpression", "setValueChangeListenerExpression");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_valueChangeListenerExpression_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_valueChangeListenerExpression_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("valueChangeListenerExpression",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.MethodBindingPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("validatorExpression", this.beanClass, "getValidatorExpression", "setValidatorExpression");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_validatorExpression_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_validatorExpression_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("validatorExpression",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.ValidatorPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("immediate", this.beanClass, "isImmediate", "setImmediate");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_immediate_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_immediate_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("immediate",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("valueChangeListener", this.beanClass, "getValueChangeListener", "setValueChangeListener");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_valueChangeListener_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_valueChangeListener_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIInput
                propertyDescriptor =
                    new PropertyDescriptor("submittedValue", this.beanClass, "getSubmittedValue", "setSubmittedValue");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIInput_submittedValue_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIInput_submittedValue_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from javax.faces.component.UIInput
                propertyDescriptor =
                    new PropertyDescriptor("localValue", this.beanClass, "getLocalValue", null);
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("UIInput_localValue_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("UIInput_localValue_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("validator", this.beanClass, "getValidator", "setValidator");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_validator_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_validator_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.ValidatorPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                // Property declaration inherited from com.sun.webui.jsf.component.WebuiInput
                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("WebuiInput_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("WebuiInput_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        if (eventSetDescriptors == null) {
            try {
                Map<String,EventSetDescriptor> eventSetDescriptorMap = new HashMap<String,EventSetDescriptor>();
                EventSetDescriptor eventSetDescriptor;
                PropertyDescriptor eventPropertyDescriptor;
                

                // Event set declaration inherited from javax.faces.component.UIInput
                eventSetDescriptor = new EventSetDescriptor("valueChange",
                    javax.faces.event.ValueChangeListener.class,
                    new Method[] {
                        javax.faces.event.ValueChangeListener.class.getMethod(
                            "processValueChange", 
                            new Class[] {javax.faces.event.ValueChangeEvent.class, })
                    },
                    Scheduler.class.getMethod("addValueChangeListener", new Class[] {javax.faces.event.ValueChangeListener.class}),
                    Scheduler.class.getMethod("removeValueChangeListener", new Class[] {javax.faces.event.ValueChangeListener.class}));
                eventPropertyDescriptor = null;
                for (PropertyDescriptor propertyDescriptor : this.getPropertyDescriptors()) {
                    if (propertyDescriptor.getName().equals("valueChangeListenerExpression")) {
                        eventPropertyDescriptor = propertyDescriptor;
                        break;
                    }
                }
                eventSetDescriptor.setValue(Constants.EventSetDescriptor.BINDING_PROPERTY, eventPropertyDescriptor);
                eventSetDescriptorMap.put(eventSetDescriptor.getName(), eventSetDescriptor);

                // Event set declaration inherited from javax.faces.component.UIInput
                eventSetDescriptor = new EventSetDescriptor("validate",
                    javax.faces.validator.Validator.class,
                    new Method[] {
                        javax.faces.validator.Validator.class.getMethod(
                            "validate", 
                            new Class[] {javax.faces.context.FacesContext.class, javax.faces.component.UIComponent.class, java.lang.Object.class, })
                    },
                    null,
                    null);
                eventPropertyDescriptor = null;
                for (PropertyDescriptor propertyDescriptor : this.getPropertyDescriptors()) {
                    if (propertyDescriptor.getName().equals("validatorExpression")) {
                        eventPropertyDescriptor = propertyDescriptor;
                        break;
                    }
                }
                eventSetDescriptor.setValue(Constants.EventSetDescriptor.BINDING_PROPERTY, eventPropertyDescriptor);
                eventSetDescriptorMap.put(eventSetDescriptor.getName(), eventSetDescriptor);

                Collection<EventSetDescriptor> eventSetDescriptorCollection = 
                    eventSetDescriptorMap.values();
                eventSetDescriptors =
                    eventSetDescriptorCollection.toArray(new EventSetDescriptor[eventSetDescriptorCollection.size()]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
