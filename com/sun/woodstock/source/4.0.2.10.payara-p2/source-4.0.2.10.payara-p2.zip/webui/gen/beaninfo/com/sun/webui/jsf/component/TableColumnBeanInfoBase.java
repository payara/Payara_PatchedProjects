package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class TableColumnBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.TableColumn.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), TableColumnBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("TableColumn_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("TableColumn_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_column");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "tableColumn");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "tableColumn");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT,
                com.sun.webui.jsf.design.CategoryDescriptors.DATA,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "TableColumn_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "TableColumn_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "TableColumn_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "TableColumn_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                

                propertyDescriptor =
                    new PropertyDescriptor("headers", this.beanClass, "getHeaders", "setHeaders");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_headers_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_headers_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onClick", this.beanClass, "getOnClick", "setOnClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("sort", this.beanClass, "getSort", "setSort");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_sort_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_sort_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("sort",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("scope", this.beanClass, "getScope", "setScope");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_scope_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_scope_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("scope",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("footerText", this.beanClass, "getFooterText", "setFooterText");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_footerText_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_footerText_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("footerText",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("visible", this.beanClass, "isVisible", "setVisible");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_visible_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_visible_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("visible",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyPress", this.beanClass, "getOnKeyPress", "setOnKeyPress");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onKeyPress_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onKeyPress_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyPress",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("char", this.beanClass, "getChar", "setChar");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_char_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_char_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("emptyCell", this.beanClass, "isEmptyCell", "setEmptyCell");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_emptyCell_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_emptyCell_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("emptyCell",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("charOff", this.beanClass, "getCharOff", "setCharOff");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_charOff_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_charOff_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("noWrap", this.beanClass, "isNoWrap", "setNoWrap");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_noWrap_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_noWrap_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("noWrap",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("embeddedActions", this.beanClass, "isEmbeddedActions", "setEmbeddedActions");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_embeddedActions_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_embeddedActions_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("embeddedActions",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("descending", this.beanClass, "isDescending", "setDescending");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_descending_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_descending_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("descending",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("id", this.beanClass, "getId", "setId");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_id_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_id_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("id",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("bgColor", this.beanClass, "getBgColor", "setBgColor");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_bgColor_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_bgColor_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseUp", this.beanClass, "getOnMouseUp", "setOnMouseUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onMouseUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onMouseUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("height", this.beanClass, "getHeight", "setHeight");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_height_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_height_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("height",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("style", this.beanClass, "getStyle", "setStyle");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_style_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_style_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("style",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.jsfcl.std.css.CssStylePropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rowHeader", this.beanClass, "isRowHeader", "setRowHeader");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_rowHeader_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_rowHeader_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rowHeader",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("colSpan", this.beanClass, "getColSpan", "setColSpan");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_colSpan_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_colSpan_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("spacerColumn", this.beanClass, "isSpacerColumn", "setSpacerColumn");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_spacerColumn_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_spacerColumn_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("spacerColumn",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rowSpan", this.beanClass, "getRowSpan", "setRowSpan");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_rowSpan_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_rowSpan_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.IntegerPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("sortImageURL", this.beanClass, "getSortImageURL", "setSortImageURL");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_sortImageURL_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_sortImageURL_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("sortImageURL",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.ImageUrlPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("selectId", this.beanClass, "getSelectId", "setSelectId");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_selectId_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_selectId_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("selectId",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.DATA);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyDown", this.beanClass, "getOnKeyDown", "setOnKeyDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onKeyDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onKeyDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraFooterHtml", this.beanClass, "getExtraFooterHtml", "setExtraFooterHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_extraFooterHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_extraFooterHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraFooterHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("axis", this.beanClass, "getAxis", "setAxis");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_axis_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_axis_shortDescription"));
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOver", this.beanClass, "getOnMouseOver", "setOnMouseOver");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onMouseOver_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onMouseOver_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOver",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("toolTip", this.beanClass, "getToolTip", "setToolTip");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_toolTip_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_toolTip_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("toolTip",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onKeyUp", this.beanClass, "getOnKeyUp", "setOnKeyUp");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onKeyUp_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onKeyUp_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onKeyUp",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("width", this.beanClass, "getWidth", "setWidth");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_width_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_width_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("width",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.LAYOUT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("styleClass", this.beanClass, "getStyleClass", "setStyleClass");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_styleClass_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_styleClass_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("styleClass",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StyleClassPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("align", this.beanClass, "getAlign", "setAlign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_align_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_align_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("align",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.TableAlignEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraTableFooterHtml", this.beanClass, "getExtraTableFooterHtml", "setExtraTableFooterHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_extraTableFooterHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_extraTableFooterHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraTableFooterHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("abbr", this.beanClass, "getAbbr", "setAbbr");
                propertyDescriptor.setHidden(true);
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_abbr_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_abbr_shortDescription"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("severity", this.beanClass, "getSeverity", "setSeverity");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_severity_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_severity_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("severity",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("rendered", this.beanClass, "isRendered", "setRendered");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_rendered_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_rendered_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("rendered",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseMove", this.beanClass, "getOnMouseMove", "setOnMouseMove");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onMouseMove_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onMouseMove_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseMove",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onDblClick", this.beanClass, "getOnDblClick", "setOnDblClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onDblClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onDblClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onDblClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("sortIcon", this.beanClass, "getSortIcon", "setSortIcon");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_sortIcon_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_sortIcon_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("sortIcon",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.ThemeIconsEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseDown", this.beanClass, "getOnMouseDown", "setOnMouseDown");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onMouseDown_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onMouseDown_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseDown",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("alignKey", this.beanClass, "getAlignKey", "setAlignKey");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_alignKey_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_alignKey_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("alignKey",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("tableFooterText", this.beanClass, "getTableFooterText", "setTableFooterText");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_tableFooterText_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_tableFooterText_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("tableFooterText",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("extraHeaderHtml", this.beanClass, "getExtraHeaderHtml", "setExtraHeaderHtml");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_extraHeaderHtml_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_extraHeaderHtml_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("extraHeaderHtml",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("valign", this.beanClass, "getValign", "setValign");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_valign_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_valign_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("valign",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.webui.jsf.component.propertyeditors.HtmlVerticalAlignEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("headerText", this.beanClass, "getHeaderText", "setHeaderText");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_headerText_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_headerText_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("headerText",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.StringPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

                propertyDescriptor =
                    new PropertyDescriptor("onMouseOut", this.beanClass, "getOnMouseOut", "setOnMouseOut");
                propertyDescriptor.setDisplayName(resourceBundle.getString("TableColumn_onMouseOut_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("TableColumn_onMouseOut_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onMouseOut",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
