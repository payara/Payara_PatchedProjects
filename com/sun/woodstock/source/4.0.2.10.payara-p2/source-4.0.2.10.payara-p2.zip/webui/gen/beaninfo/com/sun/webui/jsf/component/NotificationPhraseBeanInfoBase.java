package com.sun.webui.jsf.component;

import java.awt.Image;
import java.beans.*;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.rave.designtime.CategoryDescriptor;
import com.sun.rave.designtime.Constants;
import com.sun.rave.designtime.faces.FacetDescriptor;
import com.sun.rave.designtime.markup.AttributeDescriptor;

/**
 * This file was generated automatically on 29-Jan-2016.
 */

abstract class NotificationPhraseBeanInfoBase extends SimpleBeanInfo {
    
    /**
     * The class of the component (bean) to which this BeanInfo corresponds.
     */
    protected Class beanClass = com.sun.webui.jsf.component.NotificationPhrase.class;

    protected static ResourceBundle resourceBundle =
        ResourceBundle.getBundle("com.sun.webui.jsf.component.BeanInfoBundle", Locale.getDefault(), NotificationPhraseBeanInfoBase.class.getClassLoader());
    
    private BeanDescriptor beanDescriptor;
    

    /**
     * Return the <code>BeanDescriptor</code> for this bean.
     */
    public BeanDescriptor getBeanDescriptor() {

        if (beanDescriptor == null) {
            beanDescriptor = new BeanDescriptor(this.beanClass);
            beanDescriptor.setDisplayName(resourceBundle.getString("NotificationPhrase_displayName"));
            beanDescriptor.setShortDescription(resourceBundle.getString("NotificationPhrase_shortDescription"));
            beanDescriptor.setValue(Constants.BeanDescriptor.FACET_DESCRIPTORS,
                    this.getFacetDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.HELP_KEY, "projrave_ui_elements_palette_wdstk-jsf1.2_notification_phrase");
            beanDescriptor.setValue(Constants.BeanDescriptor.INSTANCE_NAME, "notificationPhrase");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTIES_HELP_KEY,"projrave_ui_elements_palette_wdstk-jsf1.2_propsheets_notification_phrase_props");
            beanDescriptor.setValue(Constants.BeanDescriptor.PROPERTY_CATEGORIES,
                    this.getCategoryDescriptors());
            beanDescriptor.setValue(Constants.BeanDescriptor.TAG_NAME, "notificationPhrase");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_PREFIX, "webuijsf");
            beanDescriptor.setValue(Constants.BeanDescriptor.TAGLIB_URI, "http://www.sun.com/webui/webuijsf");
        }
        return beanDescriptor;
        
    }
    
    
    private int defaultPropertyIndex = -2;
    
    /**
     * Return the index of the default property, or -1 if there is no default property.
     */
    public int getDefaultPropertyIndex() {
        if (defaultPropertyIndex == -2) {
            defaultPropertyIndex = -1;
            String defaultPropertyName = "text";
            PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors();
            if (propertyDescriptors != null) {
                for (int i = 0; i < propertyDescriptors.length; i++) {
                    if (defaultPropertyName.equals(propertyDescriptors[i].getName())) {
                        defaultPropertyIndex = i;
                        break;
                    }
                }
            }
        }
        return defaultPropertyIndex;
    }
    
    private int defaultEventIndex = -2;
    
    /**
     * Return the index of the default event, or -1 if there is no default event.
     */
    public int getDefaultEventIndex() {
        if (defaultEventIndex == -2) {
            defaultEventIndex = -1;
            String defaultEventName = "action";
            EventSetDescriptor[] eventDescriptors = getEventSetDescriptors();
            if (eventDescriptors != null) {
                for (int i = 0; i < eventDescriptors.length; i++) {
                    if (defaultEventName.equals(eventDescriptors[i].getName())) {
                        defaultEventIndex = i;
                        break;
                    }
                }
            } 
        }
        return defaultEventIndex;
    }

    private CategoryDescriptor[] categoryDescriptors;
    
    /**
     * Returns an array of <code>CategoryDescriptor</code>s, representing all
     * property categories referenced by properties of this component.
     */
    protected CategoryDescriptor[] getCategoryDescriptors() {
        if (categoryDescriptors == null) {
            categoryDescriptors = new CategoryDescriptor[]{
                com.sun.webui.jsf.design.CategoryDescriptors.APPEARANCE,
                com.sun.webui.jsf.design.CategoryDescriptors.BEHAVIOR,
                com.sun.webui.jsf.design.CategoryDescriptors.ACCESSIBILITY,
                com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT,
                com.sun.webui.jsf.design.CategoryDescriptors.ADVANCED,
            };
        }
        return categoryDescriptors;
    }
    
    private FacetDescriptor[] facetDescriptors;
    
    /**
     * Returns an array of <code>FacetDescriptor</code>s for the component.
     */
    public FacetDescriptor[] getFacetDescriptors() {
        if (facetDescriptors == null)
            facetDescriptors = new FacetDescriptor[] {};
        return facetDescriptors;
    }
    
    
    // The 16x16 color icon.
    protected String iconFileName_C16 = "NotificationPhrase_C16";
    
    // The 32x32 color icon.
    private String iconFileName_C32 = "NotificationPhrase_C32";
    
    // The 16x16 monochrome icon.
    private String iconFileName_M16 = "NotificationPhrase_M16";
    
    // The 32x32 monochrome icon.
    private String iconFileName_M32 = "NotificationPhrase_C32";
    
    /**
     * Returns an appropriate image icon (if any) for the component.
     */
    public Image getIcon(int kind) {
        String name;
        switch (kind) {
            case ICON_COLOR_16x16:
                name = iconFileName_C16;
                break;
            case ICON_COLOR_32x32:
                name = iconFileName_C32;
                break;
            case ICON_MONO_16x16:
                name = iconFileName_M16;
                break;
            case ICON_MONO_32x32:
                name = iconFileName_M32;
                break;
            default:
                name = null;
                break;
        }
        if (name == null)
            return null;
        Image image = loadImage(name + ".png");
        if (image == null)
            image = loadImage(name + ".gif");
        return image;
        
    }
    
    
    private PropertyDescriptor[] propertyDescriptors;
    
    /**
     * Returns the <code>PropertyDescriptor</code>s for this component.
     */
    public PropertyDescriptor[] getPropertyDescriptors() {

        if (propertyDescriptors == null) {
            try {
                Map<String,PropertyDescriptor> propertyDescriptorMap = new HashMap<String,PropertyDescriptor>();
                PropertyDescriptor propertyDescriptor;
                AttributeDescriptor attributeDescriptor;
                
                // Super class is a component in this library, so bring in all property
                // descriptors from the super class that have not been overridden in this
                // class now, at run-time. Since property descriptors are mutable, make
                // defensive copies of them.
                BeanInfo superBeanInfo = Introspector.getBeanInfo(loadClass("com.sun.webui.jsf.component.ImageHyperlink"));
                for (PropertyDescriptor superPropertyDescriptor : superBeanInfo.getPropertyDescriptors()) {               
                    PropertyDescriptor duplicatePropertyDescriptor = new PropertyDescriptor(
                            superPropertyDescriptor.getName(), 
                            superPropertyDescriptor.getReadMethod(), 
                            superPropertyDescriptor.getWriteMethod());
                    duplicatePropertyDescriptor.setBound(superPropertyDescriptor.isBound());
                    duplicatePropertyDescriptor.setConstrained(superPropertyDescriptor.isConstrained());
                    duplicatePropertyDescriptor.setDisplayName(superPropertyDescriptor.getDisplayName());
                    duplicatePropertyDescriptor.setExpert(superPropertyDescriptor.isExpert());
                    duplicatePropertyDescriptor.setHidden(superPropertyDescriptor.isHidden());
                    duplicatePropertyDescriptor.setPreferred(superPropertyDescriptor.isPreferred());
                    duplicatePropertyDescriptor.setPropertyEditorClass(superPropertyDescriptor.getPropertyEditorClass());
                    duplicatePropertyDescriptor.setShortDescription(superPropertyDescriptor.getShortDescription());
                    Enumeration attributeEnumeration = superPropertyDescriptor.attributeNames();
                    while (attributeEnumeration.hasMoreElements()) {
                        String attribute = (String) attributeEnumeration.nextElement();
                        duplicatePropertyDescriptor.setValue(attribute, superPropertyDescriptor.getValue(attribute));
                    }
                    propertyDescriptorMap.put(superPropertyDescriptor.getName(), duplicatePropertyDescriptor);
                }

                propertyDescriptor =
                    new PropertyDescriptor("onDblClick", this.beanClass, "getOnDblClick", "setOnDblClick");
                propertyDescriptor.setDisplayName(resourceBundle.getString("NotificationPhrase_onDblClick_displayName"));
                propertyDescriptor.setShortDescription(resourceBundle.getString("NotificationPhrase_onDblClick_shortDescription"));
                 attributeDescriptor = new AttributeDescriptor("onDblClick",false,null,true);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.ATTRIBUTE_DESCRIPTOR, attributeDescriptor);
                propertyDescriptor.setValue(Constants.PropertyDescriptor.CATEGORY, com.sun.webui.jsf.design.CategoryDescriptors.JAVASCRIPT);
                propertyDescriptor.setPropertyEditorClass(loadClass("com.sun.rave.propertyeditors.JavaScriptPropertyEditor"));
                propertyDescriptorMap.put(propertyDescriptor.getName(), propertyDescriptor);

   
                Collection<PropertyDescriptor> propertyDescriptorCollection = 
                    propertyDescriptorMap.values();
                propertyDescriptors =
                    propertyDescriptorCollection.toArray(new PropertyDescriptor[propertyDescriptorCollection.size()]);

            } catch (IntrospectionException e) {
                e.printStackTrace();
                return null;
            }
        }
         return propertyDescriptors;
    }

    private EventSetDescriptor[] eventSetDescriptors;

    public EventSetDescriptor[] getEventSetDescriptors() {
        return eventSetDescriptors;
    }
    
    /**
     * Utility method that returns a class loaded by name via the class loader that 
     * loaded this class.
     */
    private Class loadClass(java.lang.String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    
}
